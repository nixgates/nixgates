import os,sys

try:
    import urlparse
except:
    from urllib.parse import urlparse

