import datetime
import requests
import re

from resources.lib.common import tools
from resources.lib.modules.trakt_sync import movies
from resources.lib.gui import seren_dialog
from resources.lib.gui import movieMenus

class Dialog(seren_dialog.Dialog):

    def __init__(self):
        seren_dialog.Dialog.__init__(self)

        self.display_info = None
        self.list_item = None

        self.loading_text = tools.labelControl(self.window_width, self.window_height, 100, 100,
                                               "", font="font10", alignment=tools.XBFONT_CENTER_X)
        self.addControl(self.loading_text)
        self.loading_text.setLabel('Loading...')

        self.poster = tools.imageControl(100, 300, self.window_width, self.window_height, '')
        self.addControl(self.poster)

        self.heading = tools.labelControl(self.window_width, self.window_height, 100, 100,
                                          "", font="font10", alignment=tools.XBFONT_CENTER_X)
        self.addControl(self.heading)
        self._get_random_movie()

    def _get_random_movie(self):
        if self.closed:
            return
        suggest_movie_url = 'https://www.suggestmemovie.com/'

        post_data = {'mood_change': 1,
                     'mood_year1': 2000,
                     'mood_year2': datetime.date.today().year.__str__(),
                     'mood_category': '',
                     'mood_imdb_rating': 70,
                     'mood_imdb_users': 10000,
                     'mood_extra1': '',
                     'mood_extra2': '',
                     'mood_extra3': '',
                     'mood_extra4': ''}

        random_movie = requests.post(suggest_movie_url, data=post_data)
        random_movie = re.findall('imdb.com/title/(tt\d*)/"', random_movie.text)[0]

        random_movie = movies.TraktSyncDatabase().get_movie(random_movie)
        self.display_info = random_movie
        tools.log(self.display_info, 'error')
        random_movie = movieMenus.Menus().commonListBuilder([{'ids': {'trakt': self.display_info['ids']['trakt']}}],
                                                            info_return=True)[0]
        tools.log(self.display_info, 'error')
        self.list_item = random_movie

        return random_movie

    def display_movie_info(self):

        if self.list_item is None or self.display_info is None:
            return False
        tools.log(self.display_info['art']['poster'], 'error')
        tools.log(self.display_info['info']['title'], 'error')
        self.poster.setImage(self.display_info['art']['poster'])
        self.heading.setLabel(tools.colorString(self.display_info['info']['title']))

        return True

    def fetch_loop(self):
        while not self.closed:
            if self.display_movie_info():
                while not self.closed:
                    import time
                    time.sleep(5)
            else:
                self._get_random_movie()

    def doModal(self):
        seren_dialog.Dialog().doModal(self)
        self.fetch_loop()

