import requests

requests.get('')